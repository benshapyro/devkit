# Data governance

Document data sensitivity rules, approved destinations, and review/approval requirements.
