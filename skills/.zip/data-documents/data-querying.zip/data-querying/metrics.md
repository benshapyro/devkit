# Metrics

Define key metrics, dimensions, and standard filters used in analytics queries.
