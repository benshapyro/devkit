# Statistical methods

Document preferred tests, assumptions, and reporting conventions used by the team.
