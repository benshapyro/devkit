# Design system notes

Add component usage notes, design tokens, and patterns to mirror here.
