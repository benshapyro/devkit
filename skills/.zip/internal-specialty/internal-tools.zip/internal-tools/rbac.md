# RBAC

Document roles, permissions, and access control patterns required for internal tools.
