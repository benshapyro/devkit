# Audit patterns

Document audit logging requirements (who/what/when) and links to existing audit infrastructure.
