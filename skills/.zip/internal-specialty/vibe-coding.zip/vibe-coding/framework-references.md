# Framework references

Add links to official docs and preferred patterns for the frameworks used in this repo.
