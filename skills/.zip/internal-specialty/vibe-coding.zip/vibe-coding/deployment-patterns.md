# Deployment patterns

Document preferred deployment targets and patterns (e.g., Vercel/Netlify/AWS), including env var handling.
