# Patterns

Document common service patterns (endpoints, jobs, events, retries, idempotency) used in this codebase.
